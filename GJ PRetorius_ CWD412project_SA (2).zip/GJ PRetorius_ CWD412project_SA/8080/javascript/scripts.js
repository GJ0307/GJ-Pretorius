function downloadFile() {
    
    const content = projects;

    
    const blob = new Blob([content], { type: 'python/py' });

   
    const link = document.createElement('a');

   
    link.download = 'projects/ctumain', 'projects/ctuclass';
    link.href = window.URL.createObjectURL(blob);

   
    document.body.appendChild(link);

    
    link.click();

    
    document.body.removeChild(link);
}

document.getElementById('emailForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    var userName = document.getElementById('name').value;
    var userEmail = document.getElementById('email').value;
    var userMessage = document.getElementById('message').value;

    // You can perform additional validation here before sending the email

    var confirmation = confirm('Are you sure you want to send an email to ' + userName + ' (' + userEmail + ') with the following message?\n\n' + userMessage);

    if (confirmation) {
    // Assuming you have a server-side script (e.g., sendEmail.php) to handle the email sending
    // You need to replace 'sendEmail.php' with the actual path to your server-side script
    var url = 'php/contact.php';
    
    // Use an AJAX request to send the email data to the server-side script
    var xhr = new XMLHttpRequest();
    xhr.open('POST', url, true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
        alert('Email sent successfully!');
        }
    };
    
    // Send the user's name, email, and message as POST parameters
    var params = 'name=' + encodeURIComponent(userName) + '&email=' + encodeURIComponent(userEmail) + '&message=' + encodeURIComponent(userMessage);
    xhr.send(params);
    }
});
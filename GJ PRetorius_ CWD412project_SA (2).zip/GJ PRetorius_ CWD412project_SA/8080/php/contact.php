<?php
// Check if the form data is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve the form data
    $userName = $_POST["name"];
    $userEmail = $_POST["email"];
    $userMessage = $_POST["message"];

    // Set the recipient email address
    $to = "your-email@example.com"; // Replace with your email address

    // Set the subject of the email
    $subject = "New Email from $userName";

    // Compose the email message
    $message = "Name: $userName\n";
    $message .= "Email: $userEmail\n\n";
    $message .= "Message:\n$userMessage";

    // Set additional headers
    $headers = "From: $userEmail\r\n";
    $headers .= "Reply-To: $userEmail\r\n";
    $headers .= "Content-Type: text/plain; charset=utf-8\r\n";

    // Attempt to send the email
    if (mail($to, $subject, $message, $headers)) {
        // Email sent successfully
        echo "Email sent successfully!";
    } else {
        // Email failed to send
        echo "Error: Unable to send email.";
    }
} else {
    // If the script is accessed directly without form submission
    echo "Error: Invalid request.";
}
?>

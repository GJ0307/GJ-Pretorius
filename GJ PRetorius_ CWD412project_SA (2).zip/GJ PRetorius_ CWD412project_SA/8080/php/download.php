<?php

$file = fopen("projects/CWcandieinhell.zip", "r");
echo fread($file, filesize("projects/CWcandieinhell.zip"));
fclose($file);
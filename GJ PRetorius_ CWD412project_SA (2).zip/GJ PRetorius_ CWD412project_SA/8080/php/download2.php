<?php

$file = fopen("projects/pyhton.zip", "r");
echo fread($file, filesize("projects/pyhton.zip"));
fclose($file);
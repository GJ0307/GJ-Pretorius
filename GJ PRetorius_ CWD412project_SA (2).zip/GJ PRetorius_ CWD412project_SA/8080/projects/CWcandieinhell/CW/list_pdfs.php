<?php
$conn = new mysqli("localhost", "id21351714_root", "12345Ry!", "id21351714_pdfuploads");

$searchQuery = $_GET["query"];

$stmt = $conn->prepare("SELECT * FROM documents WHERE filename LIKE ? OR filepath LIKE ?");
$searchParam = "%" . $searchQuery . "%";
$stmt->bind_param("ss", $searchParam, $searchParam);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    echo "<li><a href='" . $row["filepath"] . "' download>" . $row["filename"] . "</a></li>";
}

$stmt->close();
$conn->close();
?>


<?php
if ($_FILES["pdfFile"]["error"] > 0) {
    echo "Error: " . $_FILES["pdfFile"]["error"];
} else {
    $uploadDirectory = "uploads/"; // Directory to store uploaded PDFs
    $filename = $_FILES["pdfFile"]["name"];
    $filepath = $uploadDirectory . $filename;

    move_uploaded_file($_FILES["pdfFile"]["tmp_name"], $filepath);

    // Save file information to the database (assuming you have a database connection)
    $conn = new mysqli("localhost", "id21351714_root", "12345Ry!", "id21351714_pdfuploads");
    $stmt = $conn->prepare("INSERT INTO documents (filename, filepath) VALUES (?, ?)");
    $stmt->bind_param("ss", $filename, $filepath);
    $stmt->execute();
    $stmt->close();
    $conn->close();

    echo "<a>File uploaded successfully</a>";
}
?>

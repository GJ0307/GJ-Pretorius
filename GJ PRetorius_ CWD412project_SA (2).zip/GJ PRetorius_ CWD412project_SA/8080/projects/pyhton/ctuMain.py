from ctuClass import ctuStock

shop1 = ctuStock()
shop2 = ctuStock()
shop3 = ctuStock()
shop4 = ctuStock()
customers=0
sale_item=[]
saleamount=[]
quantity_sale=[]
Sitems = ["Laptop","mouse","keyboard"]
prices = [1000, 1500, 8000]
quantity=[100,50,305]
allowed_locations=["Free State","Guateng","KZN","Limpopo","defualt"]
shops=[shop1,shop2,shop3,shop4]
while True:
    # display main menu and get user input
    print("Welcome to CTU Technologies\n")
    user_input = input("Main menu:\n1. Shop Management\n2. Sales\n3. Returns\n4. Stock\n99. Exit\nEnter your choice:")

    # process user input
    if user_input == "1":
        while True:
            print("Shop Management")
            print("1. Change shop name")
            print("2. Change shop location")
            print("3. Display current shops")
            print("4. Display all shops information")
            print("0. Back")

            # get user input for menu choice
            choice = input("Enter choice: ")
            print(quantity[2])
            # process shop management input
            if choice == "1":
                new_name = input("Enter new shop name: ")            
                shopnum=input("what shops name would you like to change")
                for i, shop in enumerate([shop1, shop2, shop3, shop4], start=1):
                    print(f"{i}. {shop.shopName}")
                if shopnum == "1":
                    shop1.shopName = new_name
                elif shopnum == "2":
                    shop2.shopName = new_name
                elif shopnum == "3":
                    shop3.shopName = new_name
                elif shopnum == "4":
                    shop4.shopName = new_name
                else:
                    print("Invalid shop number")
                
            elif choice == "2":
                print("Shops and their locations:")
                for i, shop in enumerate([shop1, shop2, shop3, shop4], start=1):
                    print(f"{i}. {shop.shopName} - {shop.Shoplocation}")

                shop_num = int(input("Enter shop number to change location: "))
                print(allowed_locations)
                new_location = input("Enter new location: ")
                for new_location in allowed_locations:
                    if shop_num == 1:
                        shop1.Shoplocation = new_location
                    elif shop_num == 2:
                        shop2.Shoplocation = new_location
                    elif shop_num == 3:
                        shop3.Shoplocation = new_location
                    elif shop_num == 4:
                        shop4.Shoplocation = new_location
                    else:
                        print("Invalid shop number")
                        break
            elif choice == "3":
                for shop in [shop1, shop2, shop3, shop4]:
                    print(f"Shop name: {shop.shopName}\nLocation: {shop.Shoplocation}\n")
            elif choice == "4":
                for i, shop in enumerate([shop1, shop2, shop3, shop4], start=1):
                    print("----------------")
                    print(f"Shop {i} Information:")
                    print(f"Name: {shop.shopName}")
                    print(f"Location: {shop.Shoplocation}")
                    print(f"Customers: {customers}")
                    print(f"Sales: {shop.sales}")
                    print(f"Returns: {shop.returns}\n")
                    print("----------------")
                    print("")
            elif choice=="0":
                break 
            else:
                print("Invalid input")
    elif user_input=="2":
        while True:
            print("\n----- Sales Menu -----")
            print("1. View items")
            print("2.view sales")
            print("0. Back")
            
            choice = input("Enter your choice: ")
            if choice == "1":
                # Display available items
                print(Sitems)
                print(prices)
                print(quantity)
                # Prompt user for purchase details
                item_name = input("Enter item name: ")

                item_quantity = int(input("Enter quantity: "))
                shop_name = int(input("Enter shop number: "))
                # Attempt to sell the item from the shop
                
                if shop_name==1:
                    if item_name =="Laptop":
                        if quantity[0] >= item_quantity:
                            customers+=1
                            saleamount.append(item_quantity * prices[2])
                            sale_item.append(item_name)
                            quantity_sale.append(quantity)
                            quantity[0] -= item_quantity
                            print(f"{item_quantity} units of Laptop successfully sold.")
                        else:
                            print(f"Insufficient stock for {item}.")
                    elif item_name =="mouse":
                        if quantity[1] >= item_quantity:
                            customers += 1
                            saleamount.append(item_quantity * prices[2])
                            sale_item.append(item_name)
                            quantity_sale.append(quantity)
                            quantity[1] -= item_quantity
                            print(f"{item_quantity} units of mouse successfully sold.")
                        else:
                            print(f"Insufficient stock for {item}.")
                    elif item_name =="keyboard":
                        if quantity[2] >= item_quantity:
                            customers += 1
                            saleamount.append(item_quantity * prices[2])
                            sale_item.append(item_name)
                            quantity_sale.append(quantity)
                            quantity[2] -= item_quantity
                            print(f"{item_quantity} units of keyboard system successfully sold.")
                        else:
                            print(f"Insufficient stock for {Sitems}.")
                   
                elif shop_name==2:
                    if item_name =="Laptop":
                        if quantity[0] >= item_quantity:
                            customers+=1
                            saleamount.append(item_quantity * prices[2])
                            sale_item.append(item_name)
                            quantity_sale.append(quantity)
                            quantity[0] -= item_quantity
                            print(f"{item_quantity} units of Laptop successfully sold.")
                        else:
                            print(f"Insufficient stock for {item}.")
                    elif item_name =="mouse":
                        if quantity[1] >= item_quantity:
                            customers += 1
                            saleamount.append(item_quantity * prices[2])
                            sale_item.append(item_name)
                            quantity_sale.append(quantity)
                            quantity[1] -= item_quantity
                            print(f"{item_quantity} units of mouse successfully sold.")
                        else:
                            print(f"Insufficient stock for {item}.")
                    elif item_name =="keyboard":
                        if quantity[2] >= item_quantity:
                            customers += 1
                            saleamount.append(item_quantity * prices[2])
                            sale_item.append(item_name)
                            quantity_sale.append(quantity)
                            quantity[2] -= item_quantity
                            print(f"{item_quantity} units of keyboard successfully sold.")
                        else:
                            print(f"Insufficient stock for {Sitems}.")
                    
                elif shop_name==3:
                    if item_name =="Laptop":
                        if quantity[0] >= item_quantity:
                            customers+=1
                            saleamount.append(item_quantity * prices[2])
                            sale_item.append(item_name)
                            quantity_sale.append(quantity)
                            quantity[0] -= item_quantity
                            print(f"{item_quantity} units of Lap cover successfully sold.")
                        else:
                            print(f"Insufficient stock for {item}.")
                    elif item_name =="mouse":
                        if quantity[1] >= item_quantity:
                            customers += 1
                            saleamount.append(item_quantity * prices[2])
                            sale_item.append(item_name)
                            quantity_sale.append(quantity)
                            quantity[1] -= item_quantity
                            print(f"{item_quantity} units of mouse successfully sold.")
                        else:
                            print(f"Insufficient stock for {item}.")
                    elif item_name =="keyboard":
                        if quantity[2] >= item_quantity:
                            customers += 1
                            saleamount.append(item_quantity * prices[2])
                            sale_item.append(item_name)
                            quantity_sale.append(quantity)
                            quantity[2] -= item_quantity
                            print(f"{item_quantity} units of keyboard successfully sold.")
                        else:
                            print(f"Insufficient stock for {Sitems}.")
                    
                elif shop_name==4:
                    if item_name =="Laptop":
                        if quantity[0] >= item_quantity:
                            customers+=1
                            saleamount.append(item_quantity * prices[2])
                            sale_item.append(item_name)
                            quantity_sale.append(quantity)
                            quantity[0] -= item_quantity
                            print(f"{item_quantity} units of Laptop successfully sold.")
                        else:
                            print(f"Insufficient stock for {item}.")
                    elif item_name =="mouse":
                        if quantity[1] >= item_quantity:
                            customers += 1
                            saleamount.append(item_quantity * prices[2])
                            sale_item.append(item_name)
                            quantity_sale.append(quantity)
                            quantity[1] -= item_quantity
                            print(f"{item_quantity} units of mouse successfully sold.")
                        else:
                            print(f"Insufficient stock for {item}.")
                    elif item_name =="keyboard":
                        if quantity[2] >= item_quantity:
                            ctuStock.customers += 1
                            saleamount.append(item_quantity * prices[2])
                            sale_item.append(item_name)
                            quantity_sale.append(quantity)
                            quantity[2] -= item_quantity
                            print(f"{item_quantity} units of keyboard successfully sold.")
                        else:
                            print(f"Insufficient stock for {Sitems}.")
            elif choice == "0":
                break
           
            elif choice=="2":
                print(sale_item)
                print(saleamount)
                print(quantity_sale)
            else:
                print("Invalid choice. Please try again.")
    elif user_input=="3":
        
            print("\nRETURN MENU")
            print("------------")
            print("Select an item to return:")
            
            # Display list of items available for return
            for i, item in enumerate(Sitems):
                print(f"{i+1}. {item}")
            
            # Prompt user for item selection
            
            while True:
                item_choice = int(input("Enter item number: "))
            # Prompt user for return quantity
                if item_choice==1:
                    item_name=Sitems[0]
                    current_stock = quantity[0]
                    return_qty = int(input(f"How many {item_name} do you want to return? (Current stock: {current_stock}) "))
                    while return_qty > current_stock or return_qty < 1:
                        print("Invalid quantity. Please enter a valid quantity.")
                        return_qty = int(input(f"How many {item_name} do you want to return? (Current stock: {current_stock}) "))
                    
                    # Prompt user for shop selection
                    print("\nWhich shop would you like to return the item to?")
                    for i, shop in enumerate(shops):
                        print("")
                    
                    # Prompt user for shop selection
                    
                    while True:
                        shop_choice = int(input("Enter shop number: "))
                        if shop_choice==1:
                            shop1.returns += return_qty
                            shop1.sales -= return_qty
                            quantity[0] += return_qty
                            print(f"\n{item_name} returned successfully to {shop1.shopName} ({shop1.Shoplocation}).")
                            print(f"New {item_name} stock: {quantity[0]}")
                            break
                        elif shop_choice==2:
                            shop2.returns += return_qty
                            shop2.sales -= return_qty
                            quantity[0] += return_qty
                            print(f"\n{item_name} returned successfully to {shop2.shopName} ({shop2.Shoplocation}).")
                            print(f"New {item_name} stock: {quantity[0]}")
                            break
                        elif shop_choice==3:
                            shop3.returns += return_qty
                            shop3.sales -= return_qty
                            quantity[0] += return_qty
                            print(f"\n{item_name} returned successfully to {shop3.shopName} ({shop3.Shoplocation}).")
                            print(f"New {item_name} stock: {quantity[0]}")
                            break
                        elif shop_choice==4:
                            shop4.returns += return_qty
                            shop4.sales -= return_qty
                            quantity[0] += return_qty
                            print(f"\n{item_name} returned successfully to {shop4.shopName} ({shop4.Shoplocation}).")
                            print(f"New {item_name} stock: {quantity[0]}")
                            break
                    break
                elif item_choice==2:
                    item_name=Sitems[1]
                    current_stock = quantity[1]
                    return_qty = int(input(f"How many {item_name} do you want to return? (Current stock: {current_stock}) "))
                    while return_qty > current_stock or return_qty < 1:
                        print("Invalid quantity. Please enter a valid quantity.")
                        return_qty = int(input(f"How many {item_name} do you want to return? (Current stock: {current_stock}) "))
                    
                    # Prompt user for shop selection
                    print("\nWhich shop would you like to return the item to?")
                    for i, shop in enumerate(shops):
                        print("")
                    
                    # Prompt user for shop selection
                    
                    while True:
                        if shop_choice==2:
                            shop1.returns += return_qty
                            shop1.sales -= return_qty
                            quantity[1] += return_qty
                            print(f"\n{item_name} returned successfully to {shop1.shopName} ({shop1.Shoplocation}).")
                            print(f"New {item_name} stock: {quantity[1]}")
                            break
                        elif shop_choice==2:
                            shop2.returns += return_qty
                            shop2.sales -= return_qty
                            quantity[1] += return_qty
                            print(f"\n{item_name} returned successfully to {shop2.shopName} ({shop2.Shoplocation}).")
                            print(f"New {item_name} stock: {quantity[1]}")
                            break
                        elif shop_choice==3:
                            shop3.returns += return_qty
                            shop3.sales -= return_qty
                            quantity[1] += return_qty
                            print(f"\n{item_name} returned successfully to {shop3.shopName} ({shop3.Shoplocation}).")
                            print(f"New {item_name} stock: {quantity[2]}")
                            break
                        elif shop_choice==4:
                            shop4.returns += return_qty
                            shop4.sales -= return_qty
                            quantity[1] += return_qty
                            print(f"\n{item_name} returned successfully to {shop4.shopName} ({shop4.Shoplocation}).")
                            print(f"New {item_name} stock: {quantity[1]}")
                            break
                
                    
                elif item_choice==3:
                    item_name=Sitems[2]
                    current_stock = quantity[2]
                    return_qty = int(input(f"How many {item_name} do you want to return? (Current stock: {current_stock}) "))
                    while return_qty > current_stock or return_qty < 1:
                        print("Invalid quantity. Please enter a valid quantity.")
                        return_qty = int(input(f"How many {item_name} do you want to return? (Current stock: {current_stock}) "))
                    
                    # Prompt user for shop selection
                    print("\nWhich shop would you like to return the item to?")
                    for i, shop in enumerate(shops):
                        print("")
                    
                    # Prompt user for shop selection
                    
                    while True:
                        shop_choice = int(input("Enter shop number: "))
                        if shop_choice==1:
                            shop1.returns += return_qty
                            shop1.sales -= return_qty
                            quantity[0] += return_qty
                            print(f"\n{item_name} returned successfully to {shop1.shopName} ({shop1.Shoplocation}).")
                            print(f"New {item_name} stock: {quantity[0]}")
                            break
                        elif shop_choice==2:
                            shop2.returns += return_qty
                            shop2.sales -= return_qty
                            quantity[0] += return_qty
                            print(f"\n{item_name} returned successfully to {shop2.shopName} ({shop2.Shoplocation}).")
                            print(f"New {item_name} stock: {quantity[0]}")
                            break
                        elif shop_choice==3:
                            shop3.returns += return_qty
                            shop3.sales -= return_qty
                            quantity[0] += return_qty
                            print(f"\n{item_name} returned successfully to {shop3.shopName} ({shop3.Shoplocation}).")
                            print(f"New {item_name} stock: {quantity[0]}")
                            break
                        elif shop_choice==4:
                            shop4.returns += return_qty
                            shop4.sales -= return_qty
                            quantity[0] += return_qty
                            print(f"\n{item_name} returned successfully to {shop4.shopName} ({shop4.Shoplocation}).")
                            print(f"New {item_name} stock: {quantity[0]}")
                            break
                    break
            
    elif user_input == "4":
        choice = input("Main menu:\n1. Display Stock\n2.add stock\n0. Return\n")
        if choice=="1":
            print(Sitems)
            print(prices)
            print(quantity)
        elif choice=="2":
            # Get item details from user
            item_name = input("Enter item name: ")
            item_price = float(input("Enter item price: "))
            item_quantity = int(input("Enter item quantity: "))
            Sitems.append(item_name)
            prices.append(item_price)
            quantity.append(item_quantity)
            print("item has been added successfully")
    elif user_input == "99":
        # exit program
        break
    else:
        print("Invalid input")

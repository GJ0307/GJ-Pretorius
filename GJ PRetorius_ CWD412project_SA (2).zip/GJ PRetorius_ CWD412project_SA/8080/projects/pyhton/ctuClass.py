class ctuStock:
    def __init__(self):
        self.__shopName = "Default"
        self.__Shoplocation = "Default"
        self.__sales = 0
        self.__returns = 0
        self.__customer=0
    @property #return the new shop name 
    def Shop_name(self): 
        return self.__shopName 
    
    @Shop_name.setter #sets the new shop name 
    def shopName(self,NewName): 
        self.__shopName = NewName 

    @property #return the new shop name 
    def Shoplocation(self):
        return self.__Shoplocation 
    
    @Shoplocation.setter #sets the new shop name
    def Shoplocation(self,new_location): 
        self.__Shoplocation = new_location 

    @property #return the new shop name 
    def sales(self):
        return self.__sales 
    
    @sales.setter #sets the new shop name
    def sales(self,sales): 
        self.__sales = sales 

    @property #return the new shop name 
    def returns(self): 
        return self.__returns 
    
    @returns.setter #sets the new shop name
    def returns(self,returns): 
        self.__returns = returns 
    
    @property #return the new shop name 
    def Sitems(self): 
        return self.__Sitems 
    
    @Sitems.setter #sets the new shop name
    def Sitems(self,items): 
        self.__Sitems = items
    
    @property #return the new shop name 
    def prices(self): 
        return self.__prices 
    
    @prices.setter #sets the new shop name
    def prices(self,price): 
        self.__prices = price

    @property #return the new shop name 
    def quantity(self): 
        return self.__quantity 
    
    @prices.setter #sets the new shop name
    def quantity(self,quantity): 
        self.__quantity = quantity

    @property #return the new shop name 
    def customers(self): 
        return self.__customer 
    
    @prices.setter #sets the new shop name
    def customers(self,customers): 
        self.__customer = customers

    def change_shop_name(self, new_shop_name):
        if new_shop_name != "":
            self.shop_name = new_shop_name
            print(f"Shop name successfully changed to {new_shop_name}.")
        else:
            print("Invalid input. Shop name cannot be blank.")

    def change_shop_location(self, new_shop_location):
        allowed_locations = ["Free State", "Gauteng", "KZN", "Limpopo", "Default"]
        if new_shop_location in allowed_locations:
            self.shop_location = new_shop_location
            print(f"Shop location successfully changed to {new_shop_location}.")
        else:
            print("Invalid input. Shop location must be one of the following: Free State, Gauteng, KZN, Limpopo, Default.")

    def display_current_shops(self):
        print("Current shop names:")
        print("-------------------")
        print(self.shop_name)

    def display_all_shops_information(self):
        print("All shop information:")
        print("---------------------")
        print(f"Shop Name: {self.shop_name}")
        print(f"Shop Location: {self.shop_location}")
        print(f"Number of Customers: {self.customers}")
        print(f"Number of Sales: {self.sales}")
        print(f"Number of Returns: {self.returns}")
        print(f"Stock Items: {self.Sitems}")

    def display_stock(self):
        print("Stock items:")
        print("------------")
        print("Item:" [self.Sitems])
        print("price:"[self.prices])
        print("Quantity:" [self.quantity])

    def add_stock(self, item, price, quantity):
        if item in self.Sitems:
            print(f"{item} already exists in stock.")
        else:
            self.Sitems[item] = {"price": price, "quantity": quantity}
            print(f"{quantity} units of {item} at {price} each successfully added to stock.")
    

    

    def return_item(self, item, quantity):
        if item in self.Sitems:
            if self.sales >= quantity * self.Sitems[item]["price"]:
                self.returns += quantity
                self.sales -= quantity * self.Sitems[item]["price"]
                self.Sitems[item]["quantity"] += quantity
                print(f"{quantity} units of {item} successfully returned.")
            else:
                print(f"No sales record found for {item}.")
        else:
            print(f"{item} not found in stock.")
    
    

    